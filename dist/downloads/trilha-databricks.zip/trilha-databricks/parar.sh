#!/bin/sh
cd "$(dirname "$0")" || exit 1
docker compose stop && echo "Parado. O progresso continua salvo."
