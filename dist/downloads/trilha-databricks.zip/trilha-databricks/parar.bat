@echo off
cd /d "%~dp0"
docker compose stop
echo Parado. O progresso continua salvo.
timeout /t 5 >nul
