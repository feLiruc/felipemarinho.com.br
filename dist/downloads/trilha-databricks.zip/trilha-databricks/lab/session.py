"""Cria a SparkSession do laboratório: Spark local + Delta Lake + metastore persistente + driver JDBC do PostgreSQL."""
import os

from delta import configure_spark_with_delta_pip
from pyspark.sql import SparkSession

DATA = os.environ.get("LAB_DATA", "/data")


def criar_spark():
    os.makedirs(f"{DATA}/warehouse", exist_ok=True)
    os.makedirs(f"{DATA}/volumes", exist_ok=True)
    # caminhos /Volumes/... dos exemplos das aulas passam a funcionar aqui dentro
    if not os.path.lexists("/Volumes"):   # no contêiner o link nasce na construção da imagem (sem root não dá em execução)
        try:
            os.symlink(f"{DATA}/volumes", "/Volumes")
        except OSError:
            pass
    builder = (
        SparkSession.builder.appName("trilha-lab")
        .master("local[*]")
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .config("spark.sql.warehouse.dir", f"{DATA}/warehouse")
        .config("spark.sql.sources.default", "delta")   # como na Databricks: tabela sem USING vira Delta
        .config("javax.jdo.option.ConnectionURL", f"jdbc:derby:;databaseName={DATA}/metastore_db;create=true")
        .config("spark.driver.memory", "2g")
        .config("spark.sql.shuffle.partitions", "8")
        .config("spark.ui.port", "4040")
        .config("spark.ui.proxyBase", "/sparkui")
        .config("spark.databricks.delta.retentionDurationCheck.enabled", "false")
        .enableHiveSupport()
    )
    return configure_spark_with_delta_pip(builder, extra_packages=["org.postgresql:postgresql:42.7.4"]).getOrCreate()
