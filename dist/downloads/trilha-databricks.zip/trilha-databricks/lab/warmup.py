"""Roda na construção da imagem: baixa os jars (Delta, JDBC) e confirma que Delta funciona."""
import os
import shutil

os.environ["LAB_DATA"] = "/tmp/warmup"
from session import criar_spark  # noqa: E402

spark = criar_spark()
spark.range(5).write.format("delta").mode("overwrite").save("/tmp/warmup/teste_delta")
assert spark.read.format("delta").load("/tmp/warmup/teste_delta").count() == 5
print("warmup ok: Spark", spark.version)
spark.stop()
shutil.rmtree("/tmp/warmup", ignore_errors=True)
open("/tmp/warmup.ok", "w").close()
if os.path.islink("/Volumes"):
    os.unlink("/Volumes")
