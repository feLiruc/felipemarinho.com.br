"""Executor de código do laboratório: recebe uma célula (Python ou SQL), roda na SparkSession e devolve texto e tabelas.

Fica preso ao 127.0.0.1 do host; o app chega aqui pelo proxy /api/lab/ do server.js.
"""
import ast
import contextlib
import ctypes
import datetime
import decimal
import io
import os
import threading
import time
import traceback
from importlib.metadata import version

from fastapi import FastAPI
from pydantic import BaseModel
from pyspark.sql import DataFrame, Row, Window
from pyspark.sql import functions as F
from pyspark.sql import types as T

import lab
from session import criar_spark

spark = criar_spark()
spark.sparkContext.setLogLevel("ERROR")
app = FastAPI()
lock = threading.Lock()
MAX_LINHAS = 50
# --- limites de segurança por célula (o isolamento principal é o contêiner; isto limita abuso e travamentos) ---
TIMEOUT = int(os.environ.get("LAB_TIMEOUT", "240"))      # segundos por célula
LIMITE_SAIDA = 1_000_000                                   # caracteres impressos por célula


class SaidaLimitada(io.StringIO):
    def write(self, s):
        if self.tell() + len(s) > LIMITE_SAIDA:
            raise RuntimeError("Saída grande demais: a célula foi interrompida (limite de 1 MB de texto).")
        return super().write(s)
_saida = []


def fmt(v):
    if v is None:
        return None
    if isinstance(v, (int, float, str, bool)):
        return v
    if isinstance(v, decimal.Decimal):
        return str(v)
    if isinstance(v, (datetime.datetime, datetime.date)):
        return v.isoformat(sep=" ") if isinstance(v, datetime.datetime) else v.isoformat()
    if isinstance(v, Row):
        return {k: fmt(x) for k, x in v.asDict().items()}
    if isinstance(v, dict):
        return {str(k): fmt(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [fmt(x) for x in v]
    return str(v)


def display(df, n=MAX_LINHAS):
    """Mostra um DataFrame como tabela no app (como o display() dos notebooks Databricks)."""
    if not isinstance(df, DataFrame):
        print(df)
        return
    linhas = df.limit(n + 1).collect()
    _saida.append({"cols": df.columns, "rows": [[fmt(x) for x in r] for r in linhas[:n]], "mais": len(linhas) > n})


def novo_ns():
    return {"spark": spark, "F": F, "Window": Window, "T": T, "lab": lab, "display": display, "__name__": "__celula__"}


ns = novo_ns()


class Celula(BaseModel):
    code: str
    lang: str = "python"
    titulo: str = ""


def rodar_python(code):
    tree = ast.parse(code, mode="exec")
    ultima = None
    if tree.body and isinstance(tree.body[-1], ast.Expr):
        ultima = ast.Expression(tree.body.pop().value)
    exec(compile(tree, "<célula>", "exec"), ns)
    if ultima is not None:
        val = eval(compile(ultima, "<célula>", "eval"), ns)
        if isinstance(val, DataFrame):
            display(val)
        elif val is not None:
            print(repr(val))


def comandos_sql(code):
    partes, atual, aspas = [], [], None
    for ch in code:
        if aspas:
            atual.append(ch)
            if ch == aspas:
                aspas = None
        elif ch in ("'", '"', "`"):
            aspas = ch
            atual.append(ch)
        elif ch == ";":
            partes.append("".join(atual))
            atual = []
        else:
            atual.append(ch)
    partes.append("".join(atual))
    limpos = []
    for p in partes:
        sem_coment = "\n".join(l for l in p.splitlines() if not l.strip().startswith("--")).strip()
        if sem_coment:
            limpos.append(sem_coment)
    return limpos


def rodar_sql(code):
    for stmt in comandos_sql(code):
        df = spark.sql(stmt)
        if df.columns:
            display(df)
        else:
            print("OK: " + stmt.split()[0].upper() + " " + (stmt.split()[1].upper() if len(stmt.split()) > 1 else ""))


def msg_erro(e):
    if getattr(e, "java_exception", None) is not None:
        return f"{type(e).__name__}: {lab.erro(e, 1800)}"
    txt = str(e).strip()
    # mensagens do Spark costumam ter o essencial na primeira linha e um stack Java enorme depois
    linhas = [l for l in txt.splitlines() if l.strip()]
    curto = "\n".join(linhas[:6])
    nome = type(e).__name__
    return f"{nome}: {curto}"[:1800]


@app.get("/health")
def health():
    return {"ok": True, "spark": spark.version, "delta": version("delta-spark")}


@app.post("/reset")
def reset():
    global ns
    with lock:
        ns = novo_ns()
        spark.catalog.clearCache()
    return {"ok": True}


def _executar(c, buf, res):
    t0 = time.time()
    erro = None
    # A sessão "ativa" do Spark é por thread na JVM; cada célula roda em uma thread própria, então ativamos aqui.
    # Sem isto, writeStream.toTable() falha com DELTA_INVALID_V1_TABLE_CALL (o Delta carrega a tabela "por caminho").
    try:
        spark._jvm.SparkSession.setActiveSession(spark._jsparkSession)
        spark.sparkContext.setJobDescription((c.titulo or c.code.strip().splitlines()[0] if c.code.strip() else "célula")[:80])
        with contextlib.redirect_stdout(buf):
            if c.lang == "sql":
                rodar_sql(c.code)
            else:
                rodar_python(c.code)
    except SyntaxError as e:
        erro = f"SyntaxError: {e.msg} (linha {e.lineno})"
    except TimeoutError:
        erro = f"Tempo esgotado: a célula passou de {TIMEOUT} s e foi interrompida."
    except Exception as e:  # noqa: BLE001 - o erro volta para o aluno ler
        erro = msg_erro(e)
        tb = traceback.extract_tb(e.__traceback__)
        linha = next((f.lineno for f in reversed(tb) if f.filename == "<célula>"), None)
        if linha:
            erro += chr(10) + f"(linha {linha} da célula)"
    res["erro"] = erro
    res["ms"] = int((time.time() - t0) * 1000)


@app.post("/run")
def run(c: Celula):
    with lock:
        _saida.clear()
        buf = SaidaLimitada()
        res = {"erro": None, "ms": 0}
        t = threading.Thread(target=_executar, args=(c, buf, res), daemon=True)
        t0 = time.time()
        t.start()
        t.join(TIMEOUT)
        if t.is_alive():
            # 1) cancela os jobs do Spark; 2) injeta TimeoutError na thread; 3) se ainda assim não sair, reinicia o executor
            try:
                spark.sparkContext.cancelAllJobs()
            except Exception:  # noqa: BLE001
                pass
            if t.ident:
                ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_ulong(t.ident), ctypes.py_object(TimeoutError))
            t.join(15)
            if t.is_alive():
                threading.Timer(1.0, lambda: os._exit(1)).start()   # o Docker religa o contêiner (restart: unless-stopped)
                return {"ok": False, "out": buf.getvalue()[-6000:], "tables": [], "error": f"Tempo esgotado ({TIMEOUT} s). O laboratório vai reiniciar; tente de novo em cerca de 1 minuto.", "ms": int((time.time() - t0) * 1000)}
        erro = res["erro"]
        return {"ok": erro is None, "out": buf.getvalue()[-6000:], "tables": list(_saida)[:5], "error": erro, "ms": res["ms"] or int((time.time() - t0) * 1000)}
