"""Ajudantes dos laboratórios: geram dados de exemplo e arquivos, imitam secrets.

Use nas células como `lab.pedidos()`, `lab.gerar_arquivos(...)`, etc.
"""
import json
import os
import random
import shutil
from datetime import date, datetime, timedelta

from pyspark.sql import SparkSession, functions as F

LOJAS = ["Londrina", "Maringá", "Curitiba", "Cascavel", "Ponta Grossa"]
STATUS = ["pago", "enviado", "entregue", "cancelado"]
JDBC_URL = "jdbc:postgresql://postgres:5432/erp"
JDBC_USUARIO = "lab"


def _spark():
    # getActiveSession é por thread; o executor roda as células em outra thread, então pega a sessão padrão
    return SparkSession.builder.getOrCreate()


def erro(e, n=220):
    """Mensagem curta e útil de uma exceção do Spark (sem o stack Java)."""
    msg = ""
    je = getattr(e, "java_exception", None)
    if je is not None:
        try:
            msg = str(je.getMessage() or je.toString())
        except Exception:  # noqa: BLE001
            msg = ""
    if not msg:
        msg = str(e)
    linhas = [l.strip() for l in msg.splitlines() if l.strip() and not l.strip().startswith("at ")]
    return (linhas[0] if linhas else type(e).__name__)[:n]


def segredo(nome):
    """Imita dbutils.secrets.get: lê o valor de uma variável de ambiente LAB_SECRET_<NOME>."""
    return os.environ["LAB_SECRET_" + nome.upper()]


def pedidos(n=100_000, skew=False, seed=42):
    """DataFrame de pedidos. Com skew=True, 70% dos pedidos são do cliente 1."""
    s = _spark()
    df = s.range(1, n + 1).withColumnRenamed("id", "pedido_id")
    cliente = (F.when(F.rand(seed) < 0.7, F.lit(1)).otherwise((F.rand(seed + 1) * 5000).cast("int") + 1)
               if skew else (F.rand(seed + 1) * 5000).cast("int") + 1)
    return (df
            .withColumn("cliente_id", cliente)
            .withColumn("loja", F.element_at(F.array(*[F.lit(x) for x in LOJAS]), (F.col("pedido_id") % 5 + 1).cast("int")))
            .withColumn("data", F.date_add(F.lit("2026-01-01").cast("date"), (F.col("pedido_id") % 300).cast("int")))
            .withColumn("valor", (F.rand(seed + 2) * 900 + 20).cast("decimal(12,2)"))
            .withColumn("status", F.element_at(F.array(*[F.lit(x) for x in STATUS]), (F.col("pedido_id") % 4 + 1).cast("int")))
            .withColumn("cupom", F.when(F.rand(seed + 3) < 0.2, F.lit("PROMO10"))))


def clientes(n=1000, sujos=False, duplicados=False, seed=7):
    """DataFrame de clientes. sujos=True traz espaços, maiúsculas, nulos e datas em texto;
    duplicados=True repete clientes com versões mais antigas (coluna atualizado_em)."""
    rnd = random.Random(seed)
    linhas = []
    base = datetime(2026, 1, 1)
    for i in range(1, n + 1):
        nome = f"Cliente {i}"
        email = f"cliente{i}@exemplo.com"
        uf = ["PR", "SC", "RS", "SP"][i % 4]
        nasc = date(1960 + i % 40, 1 + i % 12, 1 + i % 28)
        renda = f"{rnd.uniform(1500, 15000):.2f}"
        if sujos:
            if i % 7 == 0:
                email = "  " + email.upper() + " "
            if i % 11 == 0:
                uf = None
            if i % 13 == 0:
                renda = "não informado"
        versoes = 3 if duplicados and i % 5 == 0 else 1
        for v in range(versoes):
            linhas.append((i, nome, email, uf, nasc.strftime("%d/%m/%Y"), renda, base + timedelta(days=v * 10 + i % 30)))
    return _spark().createDataFrame(linhas, "cliente_id int, nome string, email string, uf string, nascimento string, renda string, atualizado_em timestamp")


def limpar(pasta):
    """Apaga uma pasta de arquivos do laboratório (e tudo dentro)."""
    shutil.rmtree(pasta, ignore_errors=True)


def listar(pasta):
    """Lista os arquivos de uma pasta, em ordem."""
    return sorted(os.listdir(pasta)) if os.path.isdir(pasta) else []


def gerar_arquivos(pasta, n_arquivos=3, linhas=100, inicio=0, formato="json", coluna_extra=None, tipo_errado=False, seed=1):
    """Escreve arquivos de eventos na pasta (JSON por linha ou CSV com cabeçalho).
    coluna_extra='desconto' acrescenta uma coluna nova; tipo_errado=True põe texto no campo valor de algumas linhas."""
    os.makedirs(pasta, exist_ok=True)
    rnd = random.Random(seed + inicio)
    criados = []
    for a in range(inicio, inicio + n_arquivos):
        nome = os.path.join(pasta, f"eventos_{a:04d}.{formato}")
        regs = []
        for k in range(linhas):
            r = {"evento_id": a * 100000 + k, "cliente_id": rnd.randint(1, 500), "tipo": rnd.choice(["view", "click", "compra"]),
                 "valor": round(rnd.uniform(1, 500), 2), "ts": f"2026-11-{1 + a % 28:02d} {k % 24:02d}:{k % 60:02d}:00"}
            if tipo_errado and k % 10 == 0:
                r["valor"] = "indisponível"
            if coluna_extra:
                r[coluna_extra] = round(rnd.uniform(0, 30), 2)
            regs.append(r)
        with open(nome, "w", encoding="utf-8") as fh:
            if formato == "json":
                fh.write("\n".join(json.dumps(r, ensure_ascii=False) for r in regs) + "\n")
            else:
                cols = list(regs[0].keys())
                fh.write(",".join(cols) + "\n")
                for r in regs:
                    fh.write(",".join(str(r[c]) for c in cols) + "\n")
        criados.append(os.path.basename(nome))
    return criados


def gerar_pedidos_json(pasta, n_arquivos=2, pedidos_por_arquivo=50, seed=3):
    """Pedidos aninhados (struct cliente, array itens), alguns sem itens, para o laboratório de JSON."""
    os.makedirs(pasta, exist_ok=True)
    rnd = random.Random(seed)
    pid = 1
    for a in range(n_arquivos):
        with open(os.path.join(pasta, f"pedidos_{a:03d}.json"), "w", encoding="utf-8") as fh:
            for _ in range(pedidos_por_arquivo):
                itens = [] if pid % 9 == 0 else [{"sku": f"SKU-{rnd.randint(1, 40):03d}", "qtd": rnd.randint(1, 5), "preco": round(rnd.uniform(5, 200), 2)} for _ in range(rnd.randint(1, 4))]
                doc = {"pedido_id": pid, "cliente": {"id": rnd.randint(1, 300), "nome": f"Cliente {pid % 300}", "endereco": {"cidade": rnd.choice(LOJAS), "uf": "PR"}},
                       "itens": itens, "tags": {"canal": rnd.choice(["app", "site", "loja"])}}
                fh.write(json.dumps(doc, ensure_ascii=False) + "\n")
                pid += 1
    return listar(pasta)
