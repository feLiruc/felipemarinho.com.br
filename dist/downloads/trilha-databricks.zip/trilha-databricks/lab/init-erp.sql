-- Banco de exemplo "ERP" para o laboratório de JDBC (objetivo 2.5).
CREATE TABLE pedidos (
  pedido_id     BIGINT PRIMARY KEY,
  cliente_id    INT NOT NULL,
  loja          TEXT NOT NULL,
  valor         NUMERIC(12,2) NOT NULL,
  status        TEXT NOT NULL,
  atualizado_em TIMESTAMP NOT NULL
);

INSERT INTO pedidos
SELECT g,
       (random() * 5000)::int + 1,
       (ARRAY['Londrina','Maringá','Curitiba','Cascavel','Ponta Grossa'])[1 + (g % 5)],
       round((random() * 900 + 20)::numeric, 2),
       (ARRAY['pago','enviado','entregue','cancelado'])[1 + (g % 4)],
       timestamp '2026-01-01' + (g || ' minutes')::interval
FROM generate_series(1, 200000) AS g;

CREATE TABLE clientes (
  cliente_id INT PRIMARY KEY,
  nome       TEXT NOT NULL,
  uf         TEXT NOT NULL
);

INSERT INTO clientes
SELECT g, 'Cliente ' || g, (ARRAY['PR','SC','RS','SP'])[1 + (g % 4)]
FROM generate_series(1, 5000) AS g;
