#!/bin/sh
cd "$(dirname "$0")" || exit 1
if ! docker info >/dev/null 2>&1; then
  echo "O Docker não está rodando. Abra o Docker Desktop (ou inicie o serviço docker) e rode de novo."
  exit 1
fi
echo "Subindo a Trilha Databricks. Na primeira vez leva de 5 a 15 minutos (baixa o Spark e o Java)."
docker compose up -d --build || exit 1
echo "Pronto: http://localhost:8790"
if command -v open >/dev/null 2>&1; then open http://localhost:8790; elif command -v xdg-open >/dev/null 2>&1; then xdg-open http://localhost:8790 >/dev/null 2>&1; fi
