// Servidor da Trilha Databricks. Sem dependências.
// - Rede local (192.168.x.x, sem cabeçalhos de proxy): SEM senha, de propósito.
// - Pelo túnel da Cloudflare (ou qualquer origem não local): senha obrigatória (auth.json, criado por set-password.js).
// Serve index.html e data/*.json e guarda o progresso em state/<trilha>.json (sincroniza PC e celular).
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = parseInt(process.env.PORT || '8790', 10);
const ROOT = __dirname;
const STATE = path.join(ROOT, 'state');
fs.mkdirSync(STATE, { recursive: true });

const MIME = { '.html': 'text/html; charset=utf-8', '.json': 'application/json; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8' };
const PUBLIC = new Set(['index.html', 'pro.html', 'guia.html', 'data/associate.json', 'data/professional.json']);

/* ---------- autenticação (só para acesso de fora da rede local) ---------- */
let AUTH = null;
function carregarAuth() { try { AUTH = JSON.parse(fs.readFileSync(path.join(ROOT, 'auth.json'), 'utf8')); } catch (e) { AUTH = null; } }
carregarAuth();
// Segunda senha, só para o laboratório quando acessado de fora da rede local (lab-auth.json, criado por set-lab-password.js).
let LABAUTH = null;
function carregarLabAuth() { try { LABAUTH = JSON.parse(fs.readFileSync(path.join(ROOT, 'lab-auth.json'), 'utf8')); } catch (e) { LABAUTH = null; } }
carregarLabAuth();
const LAB_SESSAO_MS = 12 * 3600 * 1000;
const SESSAO_MS = 7 * 24 * 3600 * 1000;
const falhas = new Map();   // ip -> { n, ate }
const MAX_FALHAS = 5, BLOQUEIO_MS = 15 * 60 * 1000;

function privado(ip) {
  ip = String(ip || '').replace(/^::ffff:/, '');
  return /^(127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|169\.254\.)/.test(ip) || ip === '::1' || /^f[cd][0-9a-f]{2}:/i.test(ip) || /^fe80:/i.test(ip);
}
// Veio pelo túnel/proxy? Qualquer cabeçalho de proxy ou origem não privada exige senha.
function exigeSenha(req) {
  const h = req.headers;
  if (h['cf-connecting-ip'] || h['cf-ray'] || h['cf-visitor'] || h['x-forwarded-for'] || h['x-forwarded-host'] || h['forwarded'] || h['x-real-ip']) return true;
  return !privado(req.socket.remoteAddress);
}
function ipCliente(req) { return String(req.headers['cf-connecting-ip'] || req.headers['x-forwarded-for'] || req.socket.remoteAddress || '?').split(',')[0].trim(); }
function ehHttps(req) { return /https/i.test(req.headers['x-forwarded-proto'] || '') || /"scheme":"https"/.test(req.headers['cf-visitor'] || ''); }
function cookies(req) { const o = {}; String(req.headers.cookie || '').split(';').forEach((c) => { const i = c.indexOf('='); if (i > 0) o[c.slice(0, i).trim()] = c.slice(i + 1).trim(); }); return o; }
function assinar(exp) { return crypto.createHmac('sha256', AUTH.secret).update('trilha.v1.' + exp).digest('hex'); }
function sessaoValida(req) {
  if (!AUTH) return false;
  const c = cookies(req).trilha_sess; if (!c) return false;
  const [exp, sig] = c.split('.'); if (!exp || !sig || +exp < Date.now()) return false;
  const esperado = assinar(exp);
  return sig.length === esperado.length && crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(esperado));
}
function senhaCorreta(pw) {
  if (!AUTH) return false;
  const h = crypto.scryptSync(String(pw), Buffer.from(AUTH.salt, 'hex'), 64, { N: 16384, r: 8, p: 1 });
  const ref = Buffer.from(AUTH.hash, 'hex');
  return h.length === ref.length && crypto.timingSafeEqual(h, ref);
}

function assinarLab(exp) { return crypto.createHmac('sha256', AUTH.secret).update('trilha.lab.v1.' + exp).digest('hex'); }
function labLiberado(req) {
  if (!AUTH || !LABAUTH) return false;
  const c = cookies(req).trilha_lab; if (!c) return false;
  const [exp, sig] = c.split('.'); if (!exp || !sig || +exp < Date.now()) return false;
  const esperado = assinarLab(exp);
  return sig.length === esperado.length && crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(esperado));
}
function labSenhaCorreta(pw) {
  if (!LABAUTH) return false;
  const h = crypto.scryptSync(String(pw), Buffer.from(LABAUTH.salt, 'hex'), 64, { N: 16384, r: 8, p: 1 });
  const ref = Buffer.from(LABAUTH.hash, 'hex');
  return h.length === ref.length && crypto.timingSafeEqual(h, ref);
}

function send(res, code, body, type, extra) {
  res.writeHead(code, Object.assign({
    'Content-Type': type || 'text/plain; charset=utf-8', 'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'X-Frame-Options': 'DENY',
  }, extra || {}));
  res.end(body);
}

const PAGINA_LOGIN = (erro) => `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Trilha Databricks</title>
<style>body{font:16px system-ui,sans-serif;background:#0E1319;color:#E7ECF2;margin:0;min-height:100vh;display:grid;place-items:center;padding:16px}form{background:#151C24;border:1px solid #273241;border-radius:10px;padding:24px;width:100%;max-width:340px}
h1{font-size:18px;margin:0 0 16px}input,button{width:100%;box-sizing:border-box;font:inherit;padding:11px;border-radius:6px;border:1px solid #273241;background:#0E1319;color:inherit}button{margin-top:12px;background:#4CC3CF;color:#04262A;border:0;font-weight:600;cursor:pointer}.e{color:#FF8A80;margin:10px 0 0;font-size:14px}</style></head>
<body><form method="post" action="/login"><h1>Trilha Databricks</h1><label for="p" style="font-size:14px;color:#9AA6B5">Senha</label><input id="p" name="senha" type="password" autocomplete="current-password" autofocus required>${erro ? '<p class="e">' + erro + '</p>' : ''}<button type="submit">Entrar</button></form></body></html>`;

function lerCorpo(req, limite, cb) {
  const chunks = []; let size = 0, estourou = false;
  req.on('data', (c) => { size += c.length; if (size > limite) { estourou = true; req.destroy(); } else chunks.push(c); });
  req.on('end', () => { if (!estourou) cb(Buffer.concat(chunks).toString('utf8')); });
}

function login(req, res) {
  const ip = ipCliente(req), f = falhas.get(ip) || { n: 0, ate: 0 };
  if (f.ate > Date.now()) return send(res, 429, PAGINA_LOGIN('Muitas tentativas. Aguarde 15 minutos.'), MIME['.html']);
  lerCorpo(req, 4096, (corpo) => {
    const senha = new URLSearchParams(corpo).get('senha') || '';
    if (senhaCorreta(senha)) {
      falhas.delete(ip);
      const exp = String(Date.now() + SESSAO_MS);
      const cookie = `trilha_sess=${exp}.${assinar(exp)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSAO_MS / 1000}${ehHttps(req) ? '; Secure' : ''}`;
      return send(res, 302, '', 'text/plain', { Location: '/', 'Set-Cookie': cookie });
    }
    f.n++; if (f.n >= MAX_FALHAS) { f.ate = Date.now() + BLOQUEIO_MS; f.n = 0; }
    falhas.set(ip, f);
    setTimeout(() => send(res, 401, PAGINA_LOGIN('Senha incorreta.'), MIME['.html']), 700);
  });
}

/* ---------- laboratório local (Docker) ---------- */
// O executor e a Spark UI ficam presos ao 127.0.0.1; o app chega a eles por aqui. Executam código: pelo túnel só com a segunda senha (lab-auth.json); na rede local, sem senha.
const LAB_HOST = process.env.LAB_HOST || '127.0.0.1';
function proxy(req, res, port, targetPath) {
  const hdr = Object.assign({}, req.headers, { host: LAB_HOST + ':' + port }); delete hdr.cookie; delete hdr.authorization;   // as credenciais do app não vão para o laboratório
  const up = http.request({ host: LAB_HOST, port, path: targetPath, method: req.method, headers: hdr }, (r) => {
    const h = Object.assign({}, r.headers);
    // a Spark UI redireciona para http://127.0.0.1:4040/...; o celular precisa do caminho relativo, sob /sparkui
    if (port === 4040 && h.location) {
      let loc = h.location.replace(/^https?:\/\/[^/]+/, '');
      if (!loc.startsWith('/sparkui')) loc = '/sparkui' + (loc.startsWith('/') ? '' : '/') + loc;
      h.location = loc;
    }
    res.writeHead(r.statusCode, h); r.pipe(res);
  });
  up.setTimeout(15 * 60 * 1000, () => up.destroy(new Error('tempo esgotado')));
  up.on('error', () => { if (!res.headersSent) send(res, 502, JSON.stringify({ ok: false, offline: true, error: 'Laboratório desligado. Rode iniciar.bat (Windows) ou sh iniciar.sh (Mac e Linux).' }), MIME['.json']); else res.end(); });
  req.pipe(up);
}

http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  let p; try { p = decodeURIComponent(url.pathname); } catch (e) { return send(res, 400, 'requisição inválida'); }
  const externo = exigeSenha(req);

  if (externo) {
    if (p === '/login') {
      if (!AUTH) return send(res, 503, 'Acesso externo desativado: senha não configurada.');
      if (req.method === 'POST') return login(req, res);
      return send(res, 200, PAGINA_LOGIN(''), MIME['.html']);
    }
    if (p === '/logout') return send(res, 302, '', 'text/plain', { Location: '/login', 'Set-Cookie': 'trilha_sess=; Path=/; HttpOnly; Max-Age=0' });
    if (!sessaoValida(req)) {
      if (!AUTH) return send(res, 503, 'Acesso externo desativado: senha não configurada.');
      if (p.startsWith('/api/')) return send(res, 401, JSON.stringify({ erro: 'não autenticado' }), MIME['.json']);
      return send(res, 302, '', 'text/plain', { Location: '/login' });
    }
    // laboratório (executa código no PC): de fora da rede local só com a segunda senha (lab-auth.json)
    if (p === '/api/labauth' && req.method === 'POST') {
      carregarLabAuth();
      if (!LABAUTH) return send(res, 403, JSON.stringify({ ok: false, erro: 'O laboratório remoto está desligado. Ele só funciona na rede local.' }), MIME['.json']);
      const chave = 'lab:' + ipCliente(req), f = falhas.get(chave) || { n: 0, ate: 0 };
      if (f.ate > Date.now()) return send(res, 429, JSON.stringify({ ok: false, erro: 'Muitas tentativas. Aguarde 15 minutos.' }), MIME['.json']);
      return lerCorpo(req, 4096, (corpo) => {
        let senha = ''; try { senha = String(JSON.parse(corpo).senha || ''); } catch (e) { /* corpo inválido */ }
        if (labSenhaCorreta(senha)) {
          falhas.delete(chave);
          const exp = String(Date.now() + LAB_SESSAO_MS);
          const cookie = `trilha_lab=${exp}.${assinarLab(exp)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${LAB_SESSAO_MS / 1000}${ehHttps(req) ? '; Secure' : ''}`;
          return send(res, 200, JSON.stringify({ ok: true }), MIME['.json'], { 'Set-Cookie': cookie });
        }
        f.n++; if (f.n >= MAX_FALHAS) { f.ate = Date.now() + BLOQUEIO_MS; f.n = 0; }
        falhas.set(chave, f);
        setTimeout(() => send(res, 401, JSON.stringify({ ok: false, erro: 'Senha do laboratório incorreta.' }), MIME['.json']), 700);
      });
    }
    if (p === '/api/labstatus') { carregarLabAuth(); return send(res, 200, JSON.stringify({ remoto: true, configurado: !!LABAUTH, liberado: labLiberado(req) }), MIME['.json']); }
    if (p.startsWith('/api/lab/') || p === '/sparkui' || p.startsWith('/sparkui/')) {
      carregarLabAuth();
      if (!LABAUTH) return send(res, 403, JSON.stringify({ ok: false, erro: 'O laboratório só funciona na rede local (acesso remoto desligado).', error: 'O laboratório só funciona na rede local (acesso remoto desligado).', precisaSenha: false }), MIME['.json']);
      if (!labLiberado(req)) return send(res, 403, JSON.stringify({ ok: false, erro: 'Informe a senha do laboratório.', error: 'Informe a senha do laboratório (aperte Executar de novo).', precisaSenha: true }), MIME['.json']);
    }
  }

  if (p.startsWith('/api/lab/')) return proxy(req, res, 8799, req.url.replace(/^\/api\/lab/, ''));
  if (p === '/sparkui' || p.startsWith('/sparkui/')) return proxy(req, res, 4040, req.url.replace(/^\/sparkui/, '') || '/');
  const m = p.match(/^\/api\/state\/([a-z0-9-]{1,40})$/);
  if (m) {
    const file = path.join(STATE, m[1] + '.json');
    if (req.method === 'GET') {
      if (!fs.existsSync(file)) return send(res, 404, 'sem estado');
      return send(res, 200, fs.readFileSync(file), MIME['.json']);
    }
    if (req.method === 'PUT') {
      return lerCorpo(req, 1024 * 1024, (body) => {
        try {
          const obj = JSON.parse(body);
          if (typeof obj !== 'object' || obj === null || Array.isArray(obj)) throw new Error('formato');
          const tmp = file + '.tmp';
          fs.writeFileSync(tmp, body); fs.renameSync(tmp, file);
          send(res, 200, 'ok');
        } catch (e) { send(res, 400, 'json inválido'); }
      });
    }
    return send(res, 405, 'método não permitido');
  }
  const rel = p === '/' ? 'index.html' : p.replace(/^\//, '');
  if (!PUBLIC.has(rel)) return send(res, 404, 'não encontrado');
  const f = path.join(ROOT, rel);
  if (!fs.existsSync(f)) return send(res, 404, 'não encontrado');
  send(res, 200, fs.readFileSync(f), MIME[path.extname(f)] || 'application/octet-stream');
}).listen(PORT, '0.0.0.0', () => console.log('Trilha Databricks em http://0.0.0.0:' + PORT + (AUTH ? ' (senha ativa para acesso externo)' : ' (SEM senha configurada: acesso externo recusado)')));
