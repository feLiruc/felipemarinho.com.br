// Servidor da Trilha Databricks para a rede local. Sem dependências. Sem senha, de propósito (rede local).
// Serve index.html e data/*.json e guarda o progresso em state/<trilha>.json (sincroniza PC e celular).
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = parseInt(process.env.PORT || '8790', 10);
const ROOT = __dirname;
const STATE = path.join(ROOT, 'state');
fs.mkdirSync(STATE, { recursive: true });

const MIME = { '.html': 'text/html; charset=utf-8', '.json': 'application/json; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8' };
const PUBLIC = new Set(['index.html', 'data/associate.json', 'data/professional.json']);

function send(res, code, body, type) {
  res.writeHead(code, { 'Content-Type': type || 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}

// Laboratório local (Docker): o executor e a Spark UI ficam presos ao 127.0.0.1; o app chega a eles por aqui.
const LAB_HOST = process.env.LAB_HOST || '127.0.0.1';
function proxy(req, res, port, targetPath) {
  const up = http.request({ host: LAB_HOST, port, path: targetPath, method: req.method, headers: Object.assign({}, req.headers, { host: LAB_HOST + ':' + port }) }, (r) => {
    const h = Object.assign({}, r.headers);
    // a Spark UI redireciona para http://127.0.0.1:4040/...; o celular precisa do caminho relativo, sob /sparkui
    if (port === 4040 && h.location) {
      let loc = h.location.replace(/^https?:\/\/[^/]+/, '');
      if (!loc.startsWith('/sparkui')) loc = '/sparkui' + (loc.startsWith('/') ? '' : '/') + loc;
      h.location = loc;
    }
    res.writeHead(r.statusCode, h); r.pipe(res);
  });
  up.setTimeout(15 * 60 * 1000, () => up.destroy(new Error('tempo esgotado')));
  up.on('error', () => { if (!res.headersSent) send(res, 502, JSON.stringify({ ok: false, offline: true, error: 'Laboratório desligado. Rode iniciar.bat (Windows) ou sh iniciar.sh (Mac e Linux).' }), MIME['.json']); else res.end(); });
  req.pipe(up);
}

http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  const p = decodeURIComponent(url.pathname);
  if (p.startsWith('/api/lab/')) return proxy(req, res, 8799, req.url.replace(/^\/api\/lab/, ''));
  if (p === '/sparkui' || p.startsWith('/sparkui/')) return proxy(req, res, 4040, req.url.replace(/^\/sparkui/, '') || '/');
  const m = p.match(/^\/api\/state\/([a-z0-9-]{1,40})$/);
  if (m) {
    const file = path.join(STATE, m[1] + '.json');
    if (req.method === 'GET') {
      if (!fs.existsSync(file)) return send(res, 404, 'sem estado');
      return send(res, 200, fs.readFileSync(file), MIME['.json']);
    }
    if (req.method === 'PUT') {
      const chunks = []; let size = 0;
      req.on('data', (c) => { size += c.length; if (size > 1024 * 1024) { res.writeHead(413); res.end(); req.destroy(); } else chunks.push(c); });
      req.on('end', () => {
        try {
          const body = Buffer.concat(chunks).toString('utf8');
          const obj = JSON.parse(body);
          if (typeof obj !== 'object' || obj === null || Array.isArray(obj)) throw new Error('formato');
          const tmp = file + '.tmp';
          fs.writeFileSync(tmp, body); fs.renameSync(tmp, file);
          send(res, 200, 'ok');
        } catch (e) { send(res, 400, 'json inválido'); }
      });
      return;
    }
    return send(res, 405, 'método não permitido');
  }
  const rel = p === '/' ? 'index.html' : p.replace(/^\//, '');
  if (!PUBLIC.has(rel)) return send(res, 404, 'não encontrado');
  const f = path.join(ROOT, rel);
  if (!fs.existsSync(f)) return send(res, 404, 'não encontrado');
  send(res, 200, fs.readFileSync(f), MIME[path.extname(f)] || 'application/octet-stream');
}).listen(PORT, '0.0.0.0', () => console.log('Trilha Databricks em http://0.0.0.0:' + PORT));
