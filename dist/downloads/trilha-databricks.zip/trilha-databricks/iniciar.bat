@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Trilha Databricks
docker info >nul 2>&1
if errorlevel 1 (
  echo.
  echo O Docker nao esta rodando. Abra o Docker Desktop, espere aparecer "Engine running" e rode este arquivo de novo.
  echo.
  pause
  exit /b 1
)
echo.
echo Subindo a Trilha Databricks. Na primeira vez leva de 5 a 15 minutos (baixa o Spark e o Java).
echo.
docker compose up -d --build
if errorlevel 1 (
  echo.
  echo Algo deu errado. Veja a mensagem acima.
  pause
  exit /b 1
)
echo.
echo Pronto: http://localhost:8790
start "" http://localhost:8790
timeout /t 5 >nul
